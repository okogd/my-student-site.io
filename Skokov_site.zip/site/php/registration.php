<?php
session_start();
$msg = "";
if (isset($_SESSION['username'])) {
echo 'Вы уже зарегистрированы';
exit;
}
if ($_POST) {
if ($_POST['password'] == $_POST['password2']) {
$fp = fopen('users.txt', 'a+');
if (!$fp) {
$fp = fopen('users.txt', 'w+');
}
$mytext = 'username='.$_POST['username'].'&password='.$_POST['password'].'&email='.$_POST['email']."&\r\n";
fwrite($fp, $mytext);
fclose($fp);
$_SESSION['username'] = $_POST['username'];
echo 'Пользователь '.$_SESSION['username'].' зарегистрирован <a href="index.php">На гостевую</a>';
exit;
} else {
$msg = 'Введенные пароли не совпадают';
}
}
?>
<html>
<head>
<meta charset="UTF-8">
<title>Регистрация</title>
<script>
function checkForm(form) {
var el, elName, value, type;
var reg = /[a-zA-Z]*@[a-zA-Z]*\.[a-zA-Z]/;
var errorList = [];
var errorText = {0: "Не заполнено поле 'Имя'", 1: "Не заполнено поле 'E-mail'"};
for (var i = 0; i < form.elements.length; i++) {
el = form.elements[i];
elName = el.nodeName.toLowerCase();
value = el.value;
if (elName == "input") {
type = el.type.toLowerCase();
if (type == "text") {
if (el.name == "username" && value == "") errorList.push(0);
if (el.name == "email" && !value.match(reg)) errorList.push(1);
}
}
}
if (!errorList.length) return true;
var errorMsg = "При заполнении формы допущены следующие ошибки:\n\n";
for (i = 0; i < errorList.length; i++) {
errorMsg += errorText[errorList[i]] + "\n";
}
alert(errorMsg);
return false;
}
</script>
</head>
<body>
<h3>Регистрация</h3>
<p style="color: red;"><?php echo $msg; ?></p>
<form method="POST" action="registration.php" onsubmit="return checkForm(this)">
<p>Имя пользователя: <input type="text" name="username"></p>
<p>Email: <input type="text" name="email"></p>
<p>Пароль: <input type="password" name="password"></p>
<p>Пароль (повторить): <input type="password" name="password2"></p>
<p><input type="submit"></p>
</form>
</body>
</html>

<?php
session_start();
$err = "";
if ($_POST) {
if (file_exists('users.txt')) {
$fp = fopen('users.txt', 'r');
while (!feof($fp)) {
$buffer = fgets($fp);
preg_match('/username=([^&]*)&/', $buffer, $user);
preg_match('/password=([^&]*)&/', $buffer, $pass);
if (isset($user[1]) && $_POST['username'] == $user[1] && $_POST['password'] == $pass[1]) {
$_SESSION['username'] = $_POST['username'];
header('Location: index.php');
exit;
}
}
fclose($fp);
}
$err = 'Неверное имя или пароль';
}
?>
<html>
<head>
<meta charset="UTF-8">
<title>Login page</title>
</head>
<body>
<h3>Войти</h3>
<p style="color: red;"><?php echo $err; ?></p>
<form method="POST" action="">
<p>Имя пользователя: <input type="text" name="username"></p>
<p>Пароль: <input type="password" name="password"></p>
<p><input type="submit"></p>
</form>
</body>
</html>

<?php
session_start();
$msg = "";
if (isset($_POST['theme']) && isset($_POST['text']) && $_POST['theme'] != "" && $_POST['text'] != "" && isset($_SESSION['username'])) {
$fp = fopen('guestbook.txt', 'a+');
if (!$fp) {
$fp = fopen('guestbook.txt', 'w+');
}
$theme = str_replace(array("&", "\r", "\n"), " ", $_POST['theme']);
$text = str_replace(array("&", "\r", "\n"), " ", $_POST['text']);
$mytext = 'username='.$_SESSION['username'].'&text='.$text.'&theme='.$theme."&\r\n";
fwrite($fp, stripslashes($mytext));
fclose($fp);
$msg = "Комментарий был успешно добавлен";
}
?>
<html>
<head>
<meta charset="UTF-8">
<title>Гостевая книга</title>
<link rel="stylesheet" href="guestbook.css">
</head>
<body>
<div class="reg">
<a href="registration.php">Регистрация</a>
<a href="login.php">Войти</a>
<p>Привет,
<?php
if (isset($_SESSION['username'])) {
echo $_SESSION['username'];
echo ' <a href="logout.php">Выйти</a>';
} else {
echo 'Гость';
}
?>
</p>
</div>
<h2>Гостевая книга</h2>
<?php
if ($msg) {
echo '<p>'.$msg.'</p>';
}
if (isset($_SESSION['username'])) {
?>
<form method="POST">
<p>Тема поста: <input type="text" name="theme"></p>
<p>Текст поста: <textarea rows="10" cols="45" name="text"></textarea></p>
<p><input type="submit"></p>
</form>
<?php
} else {
echo '<p>Чтобы оставлять комментарии вы должны быть зарегистрированы</p>';
}
?>
<table class="table">
<?php
if (file_exists('guestbook.txt')) {
$fp = fopen('guestbook.txt', 'r');
while (!feof($fp)) {
$buffer = fgets($fp);
if (trim($buffer) == "") continue;
preg_match('/username=([^&]*)&/', $buffer, $user);
preg_match('/text=([^&]*)&/', $buffer, $text);
preg_match('/theme=([^&]*)&/', $buffer, $theme);
?>
<tr class="main">
<td><?php echo htmlspecialchars($user[1]); ?></td>
<td><?php echo htmlspecialchars($theme[1]); ?></td>
</tr>
<tr class="text">
<td colspan="2"><?php echo htmlspecialchars($text[1]); ?></td>
</tr>
<?php
}
fclose($fp);
}
?>
</table>
</body>
</html>
